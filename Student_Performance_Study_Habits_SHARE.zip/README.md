# Student Performance and Study Habits Analysis

**R Programming Tiny Project**

- Student: Parmar Krish
- Enrollment No.: 2505101200281
- Division: I
- Course: BCA (Hons.)

This project demonstrates data import, preprocessing, descriptive statistics, visualisation and interpretation using a synthetic student performance and study habits dataset.

## Structure
- `data/` — dataset
- `docs/` — final 6-page PDF report
- `outputs/` — charts
- `src/` — R Markdown source
- `requirements.R` — package requirements
- `PROJECT_INFO.txt` — project details

## How to run
Run `requirements.R` once, open the `.Rmd` file in `src/` in RStudio and click **Knit**.

The dataset is synthetic and intended for academic demonstration.
