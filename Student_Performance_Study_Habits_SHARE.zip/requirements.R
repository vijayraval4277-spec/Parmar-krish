# R package requirements
install.packages(c('knitr','rmarkdown'))
library(knitr)
library(rmarkdown)
